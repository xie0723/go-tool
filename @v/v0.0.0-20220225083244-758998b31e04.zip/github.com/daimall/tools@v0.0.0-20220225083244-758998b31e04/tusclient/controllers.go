package tusclient

import "github.com/daimall/tools/curd/common"

//上传文件（创建）
type TusdController struct {
	common.BaseController
}
