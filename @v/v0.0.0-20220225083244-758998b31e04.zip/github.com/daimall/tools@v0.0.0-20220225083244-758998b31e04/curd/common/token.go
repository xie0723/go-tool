package common

const (
	TokenKey           = "X-Token"
	UserNameSessionKey = "X-UserName"
	CodeKey            = "X-Code"
	AppTag             = "APPID"
)
